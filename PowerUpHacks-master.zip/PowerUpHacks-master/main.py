from google_trans_new import google_translator
import streamlit as st
import os
import pyttsx3
text_speech = pyttsx3.init()

from gtts import gTTS

languages = {
    "Afrikaans" : "af",
    "Albanian" : "sq",
    "Arabic" : "ar",
    "Armenian":"hy",
    "Azerbaijani": "az",
    "Basque": "eu",
    "Belarusian": "be",
    "Bulgarian	": "bg",
    "Catalan": "ca",
    "Chinese ": "zh-CN",
    "Croatian": "hr",
    "Czech": "cs",
    "Danish": "da",
    "Dutch": "nl",
    "English": "en",
    "Estonian": "et",
    "Filipino": "tl",
    "Finnish": "fi",
    "French": "fr",
    "Galician": "gl",
    "Georgian": "ka",
    "German": "de",
    "Greek": "el",
    "Haitian Creole": "ht",
    "Hebrew": "iw",
    "Hindi": "hi",
    "Hungarian": "hu",
    "Icelandic": "is",
    "Indonesian": "id",
    "Irish": "ga",
    "Italian": "it",
    "Japanese": "ja",
    "Korean": "ko",
    "Latvian": "lv",
    "Lithuanian": "lt",
    "Macedonian": "mk",
    "Malay": "ms",
    "Maltese": "mt",
    "Norwegian": "no",
    "Persian": "fa",
    "Polish": "pl",
    "Portuguese": "pt",
    "Romanian": "ro",
    "Russian": "ru",
    "Serbian": "sr",
    "Slovak": "sk",
    "Slovenian": "sl",
    "Spanish": "es",
    "Swahili": "sw",
    "swedish": "sv",
    "Thai": "th",
    "Turkish": "tr",
    "Ukrainian": "uk",
    "Urdu": "ur",
    "Vietnamese": "vi",
    "Welsh": "cy",
    "Yiddish": "yi",
}
translator = google_translator()
st.title("Language Translator")
lang = st.text_input("Enter your desired translation language")

text = st.text_input("Enter your desired translation text")

lang = lang.capitalize()

if lang in languages:
    lang = languages[lang]
    translate = translator.translate(text, lang)
else:
    translate = translator.translate(text)


# sounds = gTTS(text=translate, lang=lang, slow=False)
# sounds.save("speak.mp3")
text_speech.say(translate)
text_speech.runAndWait()
st.text("\n\nYour translation:")
# os.system("mpg321 speak.mp3")
st.write(translate)
